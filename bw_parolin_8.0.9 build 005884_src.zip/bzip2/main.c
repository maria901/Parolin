#pragma warning( disable : 4101 )
#pragma warning( disable : 4102 )
#pragma warning( disable : 4018 )


#pragma comment (lib,"user32.lib")

#include <windows.h>
#include <winioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

// #define NDEBUG

#undef NDEBUG
#include <assert.h>

int main ()
{

     return 0;
}
